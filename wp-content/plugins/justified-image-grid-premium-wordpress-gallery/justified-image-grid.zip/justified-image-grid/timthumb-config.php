<?php
	define ('BLOCK_EXTERNAL_LEECHERS', true);
	define ('ALLOW_ALL_EXTERNAL_SITES', true);
?>