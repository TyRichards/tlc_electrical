<div class="wrap">
	<div class="icon32" style="background:url(<?php echo WP_PLUGIN_URL; ?>/facebook-gallery-wordpress/images/icon.jpg) top left no-repeat;"><br /></div>
	<h2>Facebook Gallery for WordPress</h2>
    <?php echo cfg_display_msg(); ?>
    <h3>Facebook Page Web Address</h3>
    Enter the web address of your <b>Page</b> (not profile). You can find this by going to the Page and copy the web address in the browser's address bar.
    <form id="adduser" method="post" action="">
        <table class="form-table">
            <tbody>
                <tr class="form-field form-required">
                    <th scope="row">
                        <label for="web-address">Web Address</label>
                    </th>
                    <td>
                        <input type="text" id="web-address" value="<?php echo $settings['web_address']; ?>" name="web_address" class="regular-text" />
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit">
        	<input class="button-primary" type="submit" value="Save Changes" name="cfg_submit" />
        </p>
    </form>
    <iframe src="http://www.facebook.com/plugins/like.php?app_id=217534408293560&amp;href=http%3A%2F%2Ffacebook.com%2Fcliftonhatfield.page&amp;send=false&amp;layout=standard&amp;width=450&amp;show_faces=true&amp;action=like&amp;colorscheme=light&amp;font&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>
    
    <h3>Instructions</h3>
    <p>After you've saved your Facebook Page web address, copy the shortcode <code>[facebook_gallery]</code> and paste it into the post editor of any post or page.</p>
    
    <h3>Having trouble?</h3>
    <ul>
        <li>- Only enter the web address to a Facebook Page and not a personal profile. Personal photos are not public and can not be displayed outside of Facebook.</li>
        <li>- Check your Facebook Page settings. The Page must be published and public. If you have any restrictions (e.g. age restriction) then the photos will not be public and cannot be displayed outside of Facebook.</li>
    </ul>
    
    <h3>Credits</h3>
    <p>
    	Facebook Gallery for WordPress is developed and maintained by <a href="http://cliftonhatfield.com" target="_blank">Clifton Hatfield</a>.
        If you have any questions or need support for this plugin, you can contact me on <a href="http://facebook.com/cliftonhatfield.page">Facebook</a>.
        Additional WordPress support can be found <a href="http://cliftonhatfield.com/wordpress-video-tutorials/" target="_blank">here</a>.
    </p>
    <h3>Premium Blog Design</h3>
    <ul>
        <li><a href="http://empoweredblogs.com">Empowered Blogs</a>
    </ul>
    <h3>Find Clifton</h3>
    <ul>
    	<li><a href="http://facebook.com/cliftonhatfield.page" target="_blank">On Facebook</a></li>
        <li><a href="http://twitter.com/cliftonhatfield" target="_blank">On Twitter</li>
        <li><a href="http://www.youtube.com/user/CliftonH" target="_blank">On Youtube</li>
        <li><a href="http://cliftonhatfield" target="_blank">On Blog</a></li>
    </ul>
    <h3>Free Plugins</h3>
    <ul>
    	<li><a href="http://lightbox.cliftonhatfield.com" target="_blank">Clifton's Lightbox Plugin</a></li>
    	<li><a href="http://cliftonhatfield.com/facebook-gallery-for-wordpress/" target="_blank">Facebook Gallery for WordPress</a></li>
    </ul>
    <h3>Javascript Library</h3>
    <p><a href="http://shadowbox-js.com/" target="_blank">Shadowbox</a> Copyright 2007-2010, Michael J. I. Jackson</p>    
    
</div>