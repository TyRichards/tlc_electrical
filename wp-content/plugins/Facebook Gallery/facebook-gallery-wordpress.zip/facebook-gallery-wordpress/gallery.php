<?php

//FACEBOOK PAGE ID
$fb_id = $page;

//FACEBOOK CONTENTS
$fb_page = file_get_contents('https://graph.facebook.com/'.$fb_id.'/albums');

//INTERPRET DATA
$albums_data = json_decode($fb_page);

if(!empty($albums_data->data))
{
	$return = '';
	
	$return .= '<ul class="fb-gallery-list">';
	
        if(!empty($album))
        {
            foreach($albums_data->data as $data)
            {
                $name = $data->name;
                if($name == $album)
                {
                    $return .= '<li class="fb-gallery-list-title"><div class="fb-gallery-name">'.$name.'</div></li>';

                    //GET PHOTOS
                    $photos = file_get_contents('https://graph.facebook.com/'.$data->id.'/photos');

                    //INTERPRET DATA
                    $photos_data = json_decode($photos, true);
                    if(!empty($photos_data))
                    {
                            $photo = array();
                            foreach($photos_data as $photo)
                            {
                                    if(is_array($photo))
                                    {
                                            $pic = array();
                                            foreach($photo as $pic)
                                            {
                                                    $images = $pic['images'];
                                                    $full = $images[0];
                                                    $full_source = $full['source'];
                                                    $thumb = $images[5];
                                                    $thumb_source = $thumb['source'];
													$likes = count($pic['likes']['data']);
                                                    $return .= '<li class="fb-gallery-list-item"><a href="'.$full_source.'" rel="shadowbox['.$name.']" class="fb-gallery-list-link" style="background:url('.$thumb_source.') center center no-repeat #FFF;"><span class="fb-gallery-photo-gradient">'.$likes.' Likes</span></a></li>';
                                            }
                                    } 
                            }
                    }
                }
            }
        }
        else
        {
            foreach($albums_data->data as $data)
            {
                    //GALLERY NAME
                    $name = $data->name;
	                $return .= '<li class="fb-gallery-list-title"><div class="fb-gallery-name">'.$name.'</div></li>';

                    //GET PHOTOS
                    $photos = file_get_contents('https://graph.facebook.com/'.$data->id.'/photos');

                    //INTERPRET DATA
                    $photos_data = json_decode($photos, true);
                    if(!empty($photos_data))
                    {
                            $photo = array();
                            foreach($photos_data as $photo)
                            {
                                    if(is_array($photo))
                                    {
                                            $pic = array();
                                            foreach($photo as $pic)
                                            {
                                                    $images = $pic['images'];
                                                    $full = $images[0];
                                                    $full_source = $full['source'];
                                                    $thumb = $images[5];
                                                    $thumb_source = $thumb['source'];
													$likes = count($pic['likes']['data']);
                                                    $return .= '<li class="fb-gallery-list-item"><a href="'.$full_source.'" rel="shadowbox['.$name.']" class="fb-gallery-list-link" style="background:url('.$thumb_source.') center center no-repeat #FFF;"><span class="fb-gallery-photo-gradient">'.$likes.' Likes</span></a></li>';
                                            }
                                    } 
                            }
                    }
            }
        }
	$return .= '</ul>';
}
else
{
	$return .= '<div class="fb-gallery-name">No photos to display. Possible errors listed below.</div>';
	$return .= '<ul>';
		$return .= '<li>You\'re Page doesn\'t have any photos to display.</li>';
		$return .= '<li>You\'ve added the wrong Facebook Page web address to the Plugin\'s Settings page.</li>';
		$return .= '<li>You have a typo in the web address.</li>';
		$return .= '<li>You put the web address to your Facebook Profile & not your Facebook Page.</li>';
	$return .= '</ul>';
}

$return .= '<div class="fb-gallery-credits" title="Facebook Gallery for WordPress built by Clifton Hatfield"><a href="http://cliftonhatfield.com/facebook-gallery-for-wordpress/" target="_blank">Facebook Gallery for WordPress</a></div>';

?>