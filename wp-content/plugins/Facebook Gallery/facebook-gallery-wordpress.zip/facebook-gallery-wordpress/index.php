<?php
/**
 * @package Facebook Gallery for WordPress
 * @version 1.3
 */
/*
Plugin Name: Facebook Gallery for WordPress
Plugin URI: http://cliftonhatfield.com
Description: Add your Facebook Page photos to your WordPress Blog.
Author: Clifton Hatfield
Version: 1.3
Author URI: http://cliftonhatfield.com
*/

/*  Copyright 20112 Clifton Hatfield  (email : clifton@cliftonhatfield.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
Change Log
09-19-2011 1.1 & 1.2
 * fixed fatal php error "Get error message Fatal error: Cannot use string offset as an array"
09-03-2012 1.3
 * Improved shortcode to expect page url and album name 
*/

/*----------------------------------------------------------------------------*/
/* Gallery shortcode
/*----------------------------------------------------------------------------*/
add_shortcode('facebook_gallery', 'cliftons_facebook_gallery');
function cliftons_facebook_gallery($atts){
    extract(shortcode_atts(array(
	'page' => '',
	'album' => '',
    ), $atts));
    
    if(empty($page))
    {
        $settings = cfg_get();
        $page = $settings['username'];
    }
    
    if(preg_match('/.com/', $page))
    {
        $web_address = mysql_real_escape_string(trim($page));
        $address_explode = explode('/', $web_address);
        $page = end($address_explode);
    }
    
    include('gallery.php');	
	
    return $return;
}

//SETTINGS MENU
add_action('admin_menu', 'cfg_settings_menu');
function cfg_settings_menu(){
    add_submenu_page('options-general.php', 'Facebook Gallery for WordPress', 'Facebook Gallery', 8, 'cfg_settings', 'cfg_settings');
}

//SETTINGS
function cfg_settings(){
	//GET SETTINGS
	$settings = cfg_get();
	include('settings.php');	
}

//SAVE SETTINGS
add_action('init', 'cfg_save');
function cfg_save(){
    if($_POST['cfg_submit'])
    {
            $web_address = mysql_real_escape_string(trim($_POST['web_address']));
            $address_explode = explode('/', $web_address);
            $username = end($address_explode);
            $settings['username'] = $username;
            $settings['web_address'] = $web_address;
            update_option('cfg_settings', $settings);
            $_SESSION['cfg_settings_msg'] = 'Changed Saved';
    }
}

//GET SETTINGS
function cfg_get(){
	return get_option('cfg_settings');
}

//DISPLAY MESSAGE
function cfg_display_msg(){
	if(!empty($_SESSION['cfg_settings_msg']))
	{
		echo '<div id="message" class="updated below-h2"><p>'.$_SESSION['cfg_settings_msg'].'</p></div>';
		$_SESSION['cfg_settings_msg'] = '';
	}
}

//STYLESHEET
add_action('wp_print_styles', 'cliftons_facebook_gallery_css');
function cliftons_facebook_gallery_css(){
	wp_register_style('cliftons_facebook_css', plugins_url('cliftons-facebook-gallery.css', __FILE__));	
	wp_register_style('cfg_shdowbox_css', plugins_url('shadowbox-3.0.3/shadowbox.css', __FILE__));	
	wp_enqueue_style('cliftons_facebook_css');
	wp_enqueue_style('cfg_shdowbox_css');
}

//JAVASCRIPT
add_action('init', 'cliftons_facebook_gallery_js');
function cliftons_facebook_gallery_js(){
	wp_register_script('cfg_shdowbox_js', plugins_url('shadowbox-3.0.3/shadowbox.js', __FILE__), array('jquery'));
	wp_enqueue_script('cfg_shdowbox_js');
}

//LAOD SHADOWBOX
add_action('wp_head', 'cfg_shadowbox');
function cfg_shadowbox(){
	echo '<script type="text/javascript">Shadowbox.init();</script>	';
}

/*-----------------------------------------------------------------------------------*/
// Update Plugin
/*-----------------------------------------------------------------------------------*/
// TEMP: Enable update check on every request. Normally you don't need this! This is for testing only!
//set_site_transient('update_plugins', null);

$api_url_cfg = 'http://update.clftn.co/';
$cfg_plugin_slug = basename(dirname(__FILE__));

add_filter('pre_set_site_transient_update_plugins', 'check_for_cfg_update');

function check_for_cfg_update($checked_data) {
	global $api_url_cfg, $cfg_plugin_slug;
	
	if (empty($checked_data->checked))
		return $checked_data;
	
	$request_args = array(
		'slug' => $cfg_plugin_slug,
		'version' => $checked_data->checked[$cfg_plugin_slug .'/index.php'],
	);
	
	$request_string = cfg_prepare_request('basic_check', $request_args);
	
	// Start checking for an update
	$raw_response = wp_remote_post($api_url_cfg, $request_string);
	
	if (!is_wp_error($raw_response) && ($raw_response['response']['code'] == 200))
		$response = unserialize($raw_response['body']);
	
	if (is_object($response) && !empty($response)) // Feed the update data into WP updater
		$checked_data->response[$cfg_plugin_slug .'/index.php'] = $response;
		
	return $checked_data;
}

// Take over the Plugin info screen
add_filter('plugins_api', 'cfg_api_call', 10, 3);

function cfg_api_call($def, $action, $args) {
	global $cfg_plugin_slug, $api_url_cfg;
	
	if ($args->slug != $cfg_plugin_slug)
		return false;
	
	// Get the current version
	$plugin_info = get_site_transient('update_plugins');
	$current_version = $plugin_info->checked[$cfg_plugin_slug .'/index.php'];
	$args->version = $current_version;
	
	$request_string = cfg_prepare_request($action, $args);
	
	$request = wp_remote_post($api_url_cfg, $request_string);
	
	if (is_wp_error($request)) {
		$res = new WP_Error('plugins_api_failed', __('An Unexpected HTTP Error occurred during the API request.</p> <p><a href="?" onclick="document.location.reload(); return false;">Try again</a>'), $request->get_error_message());
	} else {
		$res = unserialize($request['body']);
		
		if ($res === false)
			$res = new WP_Error('plugins_api_failed', __('An unknown error occurred'), $request['body']);
	}
	
	return $res;
}


function cfg_prepare_request($action, $args) {
	global $wp_version;
	
	return array(
		'body' => array(
			'action' => $action, 
			'request' => serialize($args),
			'api-key' => md5(get_bloginfo('url'))
		),
		'user-agent' => 'WordPress/' . $wp_version . '; ' . get_bloginfo('url')
	);	
}

?>